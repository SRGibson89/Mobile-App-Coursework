package com.stevengibson.photolocation;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;

import java.io.IOException;
import java.util.ArrayList;

public class ViewLocations extends AppCompatActivity {

    static ArrayList<String> places = new ArrayList<>();
    static ArrayList<LatLng> locations = new ArrayList<>();
    static ArrayAdapter arrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_locations);
/*
        //reading data back to app from file
        SharedPreferences sharedPreferences = this.getSharedPreferences("com.stevengibson.photolocation",MODE_PRIVATE);
        ArrayList<String> latitudes = new ArrayList<>();
        ArrayList<String> longitudes = new ArrayList<>();

        places.clear();
        latitudes.clear();
        longitudes.clear();
        locations.clear();

        try
        {

            places = (ArrayList<String>)ObjectSerializer.deserialize(sharedPreferences.getString("places",ObjectSerializer.serialize(new ArrayList<String>())));

            latitudes = (ArrayList<String>)ObjectSerializer.deserialize(sharedPreferences.getString("latitudes",ObjectSerializer.serialize(new ArrayList<String>())));

            longitudes = (ArrayList<String>)ObjectSerializer.deserialize(sharedPreferences.getString("longitudes",ObjectSerializer.serialize(new ArrayList<String>())));


        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        if (places.size() >0 && longitudes.size() >0 && latitudes.size() >0)
        {
            if (places.size() == latitudes.size() && latitudes.size() == longitudes.size())
            {
                for (int i = 0; i<latitudes.size();i++)
                {
                    locations.add(new LatLng(Double.parseDouble(latitudes.get(i)),Double.parseDouble(longitudes.get(i))));
                }
            }
        }
        else
        {
            places.add("No places found");
            locations.add(new LatLng(55,3));
        }
*/


        ListView listView =(ListView)findViewById(R.id.Locations);

        arrayAdapter =new ArrayAdapter(this, android.R.layout.simple_list_item_1,places);

        listView.setAdapter(arrayAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent LocationIntent = new Intent(getApplicationContext(),UsersLocation.class);
                LocationIntent.putExtra("placename",position);

                startActivity(LocationIntent);

            }
        });
        //delete an item
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, final long id) {
                final int itemId = position;
                final String MyTitle="";
                final EditText input = new EditText(ViewLocations.this);
                new AlertDialog.Builder(ViewLocations.this)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setTitle("What do you want to do?")

                        .setPositiveButton("Rename", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which)
                            {
                                new AlertDialog.Builder(ViewLocations.this)
                                        .setIcon(android.R.drawable.ic_menu_edit)
                                        .setTitle("Rename")
                                        .setView(input)
                                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {

                                                String MyTitle = input.getEditableText().toString();
                                                places.set(itemId,MyTitle);
                                            }
                                        })
                                        .setNegativeButton("Cancel",null)
                                        .show();
                            }
                        })
                        .setNegativeButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which)
                            {
                                new AlertDialog.Builder(ViewLocations.this)
                                        .setIcon(android.R.drawable.ic_delete)
                                        .setTitle("Are you sure?")
                                        .setMessage("Do you want to delete this location?")
                                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                locations.remove(itemId);
                                                places.remove(itemId);
                                                arrayAdapter.notifyDataSetChanged();
                                            }
                                            //end of onClick()
                                        })
                                        .setNegativeButton("No",null)
                                        .show();
                            }
                        })
                        .show();


                return true;
                //end of onItemLonClick()
            }
            //end of listView.set
        });

        //end of oncreate()
        }










    public void btnBack_onclick(View view)
    {

        Intent intent = new Intent(getApplicationContext(),MainActivity.class);

        startActivity(intent);
        //Resave list incase any location were deleted.
        SharedPreferences sharedPreferences = this.getSharedPreferences("com.stevengibson.photolocation",MODE_PRIVATE);
        try
        {
            ArrayList<String> latitudes = new ArrayList<>();
            ArrayList<String> longitudes = new ArrayList<>();

            for (LatLng coordinates : ViewLocations.locations)
            {
                latitudes.add(Double.toString(coordinates.latitude));
                longitudes.add(Double.toString(coordinates.longitude));
            }

            sharedPreferences.edit().putString("places", ObjectSerializer.serialize(ViewLocations.places)).apply();
            sharedPreferences.edit().putString("latitudes", ObjectSerializer.serialize(latitudes)).apply();
            sharedPreferences.edit().putString("longitudes", ObjectSerializer.serialize(longitudes)).apply();
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }

//end of activty
}
